package org.cvtc.shapes;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */

// subclass Cylinder inherits from Shape superclass
public class Cylinder extends Shape {

	// Variables
	private float radius = 0.0f,
				  height = 0.0f;
	
	// Getters and Setters for radius, height,
	// getRadius
	public float getRadius() {
		return radius;
	}
	
	// getHeight
	public float getHeight() {
		return height;
	}

	// setRadius
	public void setRaidus(float radius) {
		this.radius = radius;
	}
	
	// setHeight
	public void setHeight(float height) {
		this.height = height;
	}

	// Cylinder constructor
	public Cylinder(float radius, float height) {
		
	}

	// Calculate surface area
	@Override
	public float surfaceArea() {
		// Constant to calculate surface area
		final float SA = (float) ((2 * Math.PI * radius * height) + (2 * Math.PI * radius * radius));
		return SA;
	}

	// Calculate volume
	@Override
	public float volume() {
		return (float) (Math.PI * radius * radius * height);
	}
	
	// render()
	// show a shape's dimension, surface area, and volume via simple message box
	// all dimensions unitless
	@Override
	public void render() {
		
		//custom title, no icon
		JOptionPane.showMessageDialog(null,
		    "Radius: " + radius + "\n"
		    + "Height: " + height + "\n"
		    + "Surface Area: " + surfaceArea() + "\n"
		    + "Volume: " + volume(),
		    "Cylinder Dimensions, Surface Area, and Volume",
		    JOptionPane.PLAIN_MESSAGE);
	}

}

