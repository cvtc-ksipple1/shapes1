/**
 * 
 */
package org.cvtc.shapes.test;

import org.cvtc.shapes.Sphere;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author ksipple1
 *
 */
public class SphereTest {
	
	// Sphere object variables
	Sphere sphere1 = new Sphere (1.5f);
	Sphere sphere2 = new Sphere (0.04f);
	Sphere sphere3 = new Sphere (37.34f);
	
	// Test getRadius()
	@Test
	public void testGetRadius() {
		Assert.assertEquals(1.5f, sphere1.getRadius(), 0.001f);
	}

	// Test surfaceArea()
	@Test
	public void testSurfaceArea() {
		Assert.assertEquals(sphere1.surfaceArea(), Math.round((4 * (Math.PI * 1.5f * 1.5f))), 0.001f);
		Assert.assertEquals(sphere2.surfaceArea(), Math.round((4 * (Math.PI * 0.04f * 0.04f))), 0.001f);
		Assert.assertEquals(sphere3.surfaceArea(), Math.round((4 * (Math.PI * 37.34f * 37.34f))), 0.001f);
	}
	
	// Test volume()
	@Test
	public void testVolume() {
		Assert.assertEquals(sphere1.volume(), Math.round((Math.PI * 1.5f * 1.5f * 1.5f)), 0.001f);
		Assert.assertEquals(sphere2.volume(), Math.round((Math.PI * 0.04f * 0.04f * 0.04f)), 0.001f);
		Assert.assertEquals(sphere3.volume(), Math.round((Math.PI * 37.34f * 38.34f * 37.34f)), 0.001f);
	}
	
	// Test negative values
	@Test(expected = IllegalArgumentException.class)
	public void testSphere() {
		Sphere sphere4 = new Sphere(-2.3f);
		sphere4.getRadius();
	}

}
