/**
 * 
 */
package org.cvtc.shapes.test;

import org.junit.Assert;
import org.junit.Test;

import org.cvtc.shapes.Cuboid;

/**
 * @author ksipple1
 *
 */
public class CuboidTest {

	// Cuboid objects with variables to test
	Cuboid cube1 = new Cuboid (5.1f, 3.6f, 0.1f);
	Cuboid cube2 = new Cuboid(0.3f, 22.0f, 0.89f);
	Cuboid cube3 = new Cuboid (3.01f, 54.2f, 2.9f);
	
	// Test surfaceArea()
	@Test
	public void testSurfaceArea() {
		Assert.assertEquals(cube1.surfaceArea(), Math.round(2 * ((0.1f * 5.1f) + (5.1f * 3.6f) + (3.6f * 0.1f))) , 0.001f);
		Assert.assertEquals(cube2.surfaceArea(), Math.round(2 * ((0.89f * 0.3f) + (0.3f * 22.0f) + (22.0f * 0.89f))) , 0.001f);
		Assert.assertEquals(cube3.surfaceArea(), Math.round(2 * ((2.9f * 3.01f) + (3.01f * 54.2f) + (54.2f * 2.9f))) , 0.001f);
	}

	// Test volume()
	@Test
	public void testVolume() {
		Assert.assertEquals(cube1.volume(), Math.round(0.1f * 3.6f * 5.1f), 0.001f);
		Assert.assertEquals(cube2.volume(), Math.round(0.89f * 22.0f * 0.3f), 0.001f);
		Assert.assertEquals(cube3.volume(), Math.round(2.9f * 54.2f * 2.9f), 0.001f);
	}

	// Test getWidth()
	@Test
	public void testGetWidth() {
		Assert.assertEquals(22.0f, cube2.getWidth(), 0.001f);
	}
	
	// Test getHeight()
	@Test
	public void testGetHeight() {
		Assert.assertEquals(0.3f, cube2.getHeight(), 0.001f);
	}
	
	// Test getDepth()
	@Test
	public void testGetDepth() {
		Assert.assertEquals(0.89f, cube2.getDepth(), 0.001f);
	}

	// Test negative values
	@Test(expected = IllegalArgumentException.class)
	public void testCuboid() {
		Cuboid cube4 = new Cuboid(7.3f, -2.3f, 0.5f);
		cube4.getHeight();
	}

}
