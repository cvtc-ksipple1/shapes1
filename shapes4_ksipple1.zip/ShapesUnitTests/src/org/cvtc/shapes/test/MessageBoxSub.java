package org.cvtc.shapes.test;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */
public class MessageBoxSub {
	
	public int show() {
		return JOptionPane.OK_OPTION;
	}

}
