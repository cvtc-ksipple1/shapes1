package org.cvtc.shapes;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */

// subclass Cuboid inherits from Shape superclass
// and inherits interface Renderer
public class Cuboid extends Shape implements Renderer {

	// Variables
	private float width = 0.0f,
				  height = 0.0f,
				  depth = 0.0f;
	
	// Getters and Setters for width, height, and width
	// getWidth
	public float getWidth() {
		return width;
	}
	
	// getHeight
	public float getHeight() {
		return height;
	}
	
	// getDepth
	public float getDepth() {
		return depth;
	}

	// setWidth
	public void setWidth(float width) {
		this.width = width;
	}
	
	// setHeight
	public void setHeight(float height) {
		this.height = height;
	}
	
	// setDepth
	public void setDepth(float depth) {
		this.depth = depth;
	}

	// Cuboid constructor
	public Cuboid(Dialog messageBox, float width, float height, float depth) {
		super(messageBox);
	}

	// Calculate surface area
	@Override
	public float surfaceArea() {
		// Constant to calculate surface area
		final float SA = 2 * ((depth * width) + (width * height) + (height * depth));
		return SA;
	}

	// Calculate volume
	@Override
	public float volume() {
		return (depth * height * width);
	}
	
	// render()
	// show a shape's dimension, surface area, and volume via simple message box
	// all dimensions unitless
	public void render() {
		
		// Simple message box showing the dimensions, surface area, and volume
		JOptionPane.showMessageDialog(null,
		    "Width: " + width + "\n"
		    + "Height: " + height + "\n"
		    + "Depth: " + depth + "\n"
		    + "Surface Area: " + surfaceArea() + "\n"
		    + "Volume: " + volume(),
		    "Cuboid Dimensions, Surface Area, and Volume",
		    JOptionPane.PLAIN_MESSAGE);
	}

}
