package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */

// Superclass abstract Shape
public abstract class Shape {
	
	// Variable
	static Dialog messageBox;
	
	// getMessageBox method
	public Dialog getMessageBox() {
		return messageBox;
	}
	
	// setMessageBox method
	public void setMessageBox(Dialog messageBox) {
		Shape.messageBox = messageBox;
	}
	
	// Shape Constructor
	public Shape(Dialog messageBox) {
		
	}
	
	// surfaceArea abstract method
	public abstract float surfaceArea();
	
	// volume abstract method
	public abstract float volume();
}
