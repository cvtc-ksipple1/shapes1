package org.cvtc.shapes;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */
public abstract class MessageBox implements Dialog{

	Dialog dialog;
	
	// MessageBox Constructor
	public MessageBox() {
		this.dialog = new Dialog() {
		};
	}
	
	public static int show(String message, String title) {
		return JOptionPane.OK_OPTION;
	}
}
