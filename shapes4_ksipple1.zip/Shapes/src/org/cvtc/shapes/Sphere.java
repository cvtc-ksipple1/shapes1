package org.cvtc.shapes;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */

// subclass Sphere inherits from Shape superclass
public class Sphere extends Shape implements Renderer {

	// Variables
	private float radius = 0.0f;
	
	// Getter and setter for radius
	// getRadius
	public float getRadius() {
		return radius;
	}
		
	// setRadius
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	// Sphere constructor
	public Sphere(Dialog messageBox, float radius) {
		super(messageBox);
	}

	// Calculate surface area
	@Override
	public float surfaceArea() {
		// Constant to calculate surface area
		final float SA = (float) (4 * (Math.PI * radius * radius));
		return SA;
	}

	// Calculate volume
	@Override
	public float volume() {
		return (float) ((4/3) * (Math.PI * radius * radius * radius));
	}
	
	// render()
	// show a shape's dimension, surface area, and volume via simple message box
	// all dimensions unitless
	public void render() {
		
		//custom title, no icon
		JOptionPane.showMessageDialog(null,
		    "Radius: " + radius + "\n"
		    + "Surface Area: " + surfaceArea() + "\n"
		    + "Volume: " + volume(),
		    "Sphere Dimensions, Surface Area, and Volume",
		    JOptionPane.PLAIN_MESSAGE);
	}

}
