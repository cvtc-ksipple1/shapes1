package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */
public interface Dialog {
	
	public static int show(String message, String title) {
		
		return show("", "");
		
	}

}
