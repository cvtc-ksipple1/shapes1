/**
 * 
 */
package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */

// Superclass abstract Shape
public abstract class Shape {
	
	// surfaceArea abstract method
	public abstract float surfaceArea();
	
	// volume abstract method
	public abstract float volume();
	
	// render abstract method
	// show a shape's dimension, surface area, and volume via simple message box
	// all dimensions unitless
	public abstract void render();
	

}
