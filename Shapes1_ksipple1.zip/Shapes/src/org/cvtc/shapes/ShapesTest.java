package org.cvtc.shapes;

import javax.swing.JOptionPane;

/**
 * @author ksipple1
 *
 */
public class ShapesTest {
	
	// Main method
	public static void main(String[] args) {
		
		// Constant
		// Minimum number that a dimension can be
		final float MIN_DIMENSION = 0.0f;
		
		// Variables
		// float variables for calculations
		float height = MIN_DIMENSION;
		float width = MIN_DIMENSION;
		float depth = MIN_DIMENSION;
		float radius = MIN_DIMENSION;
		
		// String variables for user input
		String strWidth;
		String strHeight;
		String strDepth;
		String strRadius;
		
		// Boolean variable for while loop to validate input is a positive float
		boolean posNum = false;

		//
		//
		
		// Create a new Cuboid object
		Cuboid cuboid = new Cuboid(height, width, depth);
		
		// Width
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the width
			strWidth = JOptionPane.showInputDialog("Please enter the width of the cuboid:");
			
			// Try-Catch block to validate input is a number
			try {
				
				// Convert from String to float
				width = Float.parseFloat(strWidth);
				
				if (width < MIN_DIMENSION) {
					
					strWidth = (JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the width of the cuboid:</b><br>"
						+ "Width must be a positive number."));
					
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				strWidth = (JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the width of the cuboid:</b><br>"
					+ "Width must be a positive number."));
				
			}
			
			// Validate that the width is a positive number
		} while(!posNum);
			
		// Pass the cuboid's width back to the set method
		cuboid.setWidth(width);
		
		// Height
		
		// Use a do-while loop to validate that input is a positive number
		do {
		
			// Get the height
			strHeight = (JOptionPane.showInputDialog("Please enter the height of the cuboid:"));
			
			// Try-Catch block to validate input is a number
			try {
				
				// Convert from String to float
				height = Float.parseFloat(strHeight);
				
				// Check if height is a positive number
				if (height < MIN_DIMENSION) {
					
					strHeight = (JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
						+ "Height must be a positive number."));
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				strHeight = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the height"
						+ " of the cuboid:</b><br>"
					+ "Height must be a positive number.");
			}
			
		} while(!posNum);
			
		// Pass the cuboid's height back to the set method
		cuboid.setHeight(height);
		
		// Depth
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
		// Get the depth
		strDepth = (JOptionPane.showInputDialog("Please enter the depth of the cuboid:"));
		
		// Try-Catch block to validate input is a number
		try {
			
			// Convert from String to float
			depth = Float.parseFloat(strDepth);
			
			// Validate that the depth is a positive number
			if (depth < MIN_DIMENSION) {
				
				// Error message/try again
				strDepth = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the depth of the cuboid:</b><br>"
						+ "Depth must be a positive number.");
			}
			
			posNum = true;
			
		} catch (NumberFormatException e) {
			
			// Error message/try again
			strDepth = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the depth of the cuboid:</b><br>"
				+ "Depth must be a positive number.");
			
		}
		
	} while(!posNum);
		
		// Pass the cuboid's depth back to the set method
			cuboid.setDepth(depth);
		
		//
		//
		
		// Create a new Cylinder object
		Cylinder cylinder = new Cylinder(radius, height);
		
		// Radius
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
		// Get the radius
		strRadius = (JOptionPane.showInputDialog("Please enter the radius of the cylinder"));
		
		// Try-Catch block to validate input is a number
		try {
			
			// Convert from String to float
			radius = Float.parseFloat(strRadius);
			
			// Validate that the radius is a positive number
			if (radius < MIN_DIMENSION) {
				
				// Error message/try again
				strRadius = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
						+ "Radius must be a positive number.");
			}
			
			posNum = true;
			
		} catch (NumberFormatException e) {
			
			strRadius = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
				+ "Radius must be a positive number.");
		}
		
		
	} while(!posNum);
		
		// Set the cylinder's radius back to the set method
		cylinder.setRaidus(radius);
		
		// Height
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the height
			strHeight = (JOptionPane.showInputDialog("Please enter the height of the cylinder:"));
			
			// Try-Catch block to validate input is a number
			try {
				
				// Convert from String to float
				height = Float.parseFloat(strHeight);
				
				// Validate that the width is a positive number
				if (height < MIN_DIMENSION) {
					
					// Error message/try again
					strHeight = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
							+ "Height must be a positive number.");
					
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				// Error message/try again
				strHeight = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
					+ "Height must be a positive number.");
			}
			
		} while(!posNum);
			
		// Set the cylinder's height back to the set method
		cylinder.setHeight(height);
			
		//
		//
		
		// Create a new Sphere object
		Sphere sphere = new Sphere(radius);
		
		// Radius
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the radius
			strRadius = (JOptionPane.showInputDialog("Please enter the radius of the sphere."));
			
			// Try-Catch block to validate input is a number
			try {
				
				// Convert from String to float
				radius = Float.parseFloat(strRadius);
				
				// Validate that the radius is a positive number
				if (radius < MIN_DIMENSION) {
					
					// Error message/try again
					strRadius = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
							+ "Radius must be a positive number.");
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				// Error message/try again
				strRadius = JOptionPane.showInputDialog("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
					+ "Radius must be a positive number.");
			}
			
		} while(!posNum);
		
		// Set the sphere's radius back to the set method
		sphere.setRadius(radius);
		
		// Call the render method for the dialog boxes for each shape
		// 3 boxes total
		cuboid.render();
		cylinder.render();
		sphere.render();
		
	}

}
