/**
 * 
 */
package org.cvtc.shapes.test;

import org.cvtc.shapes.Cylinder;
import org.junit.Assert;
import org.junit.Test;


/**
 * @author ksipple1
 *
 */
public class CylinderTest {

	// Cylinder object variables for testing
	Cylinder cylinder1 = new Cylinder(null, 0.05f, 6.8f);
	Cylinder cylinder2 = new Cylinder(null, 2.73f, 17.3f);
	Cylinder cylinder3 = new Cylinder(null, 8.3f, 0.56f);
	
	// Test getRadius()
	@Test
	public void testGetRadius() {
		Assert.assertEquals(0.05f, cylinder1.getRadius(), 0.001f);
	}

	// Test getHeight()
	@Test
	public void testGetHeight() {
		Assert.assertEquals(6.8f, cylinder1.getHeight(), 0.001f);
	}
	
	// Test surfaceArea()
	@Test
	public void testSurfaceArea() {
		Assert.assertEquals(cylinder1.surfaceArea(), Math.round(((2 * Math.PI * 0.05f * 6.8f) + (2 * Math.PI * 0.05f * 0.05f))), 0.001f);
		Assert.assertEquals(cylinder2.surfaceArea(), Math.round(((2 * Math.PI * 2.73f * 17.3f) + (2 * Math.PI * 2.73f * 2.73f))), 0.001f);
		Assert.assertEquals(cylinder3.surfaceArea(), Math.round(((2 * Math.PI * 8.3f * 0.56f) + (2 * Math.PI * 8.3f * 8.3f))), 0.001f);
	}
	
	// Test volume()
	@Test
	public void testVolume() {
		Assert.assertEquals(cylinder1.volume(), (Math.PI * 0.05f * 0.05f * 6.8f), 0.001f);
		Assert.assertEquals(cylinder2.volume(), (Math.PI * 2.73f * 2.73f * 17.3f), 0.001f);
		Assert.assertEquals(cylinder3.volume(), (Math.PI * 8.3f * 8.3f * 0.56f), 0.001f);
	}
	
	// Test negative values
	@Test(expected = IllegalArgumentException.class)
	public void testCylinder() {
		Cylinder cylinder4 = new Cylinder(null, 7.3f, -2.3f);
		cylinder4.getHeight();
	}
	
}
