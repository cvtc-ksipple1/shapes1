package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */
public enum ShapeType {
	
	Cuboid, Cylinder, Sphere;

}
