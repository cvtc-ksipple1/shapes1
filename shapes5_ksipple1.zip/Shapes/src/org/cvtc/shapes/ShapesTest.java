package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */
public class ShapesTest {
	
	// Main method
	public static void main(String[] args) {
		
		// Constant
		// Minimum number that a dimension can be
		final float MIN_DIMENSION = 0.0f;
		
		// Variables
		// float variables for calculations
		float height = MIN_DIMENSION;
		float width = MIN_DIMENSION;
		float depth = MIN_DIMENSION;
		float radius = MIN_DIMENSION;
		
		// Boolean variable for while loop to validate input is a positive float
		boolean posNum = false;
		
		// Dialog messageBox variable
		Dialog messageBox = null;
		
		// Create a new ShapeFactory 
		ShapeFactory shapeFactory = new ShapeFactory(messageBox);

		//
		//
		// Create a new Cuboid object
		Cuboid cuboid = new Cuboid(messageBox, height, width, depth);
		
		Shape cuboid1 = shapeFactory.make(ShapeType.Cuboid);
		cuboid1.setMessageBox(null);
		
		// Width
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the width
			width = MessageBox.show("Please enter the width of the cuboid:", "Cuboid");
			
			// Try-Catch block to validate input is a number
			try {
				
				if (width < MIN_DIMENSION) {
					
					width = (MessageBox.show("<html><b style='color:red'>Please enter the width of the cuboid:</b><br>"
						+ "Width must be a positive number.", "Cuboid - Error"));
					
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				width = (MessageBox.show("<html><b style='color:red'>Please enter the width of the cuboid:</b><br>"
					+ "Width must be a positive number.", "Cuboid - Error"));
				
			}
			
			// Validate that the width is a positive number
		} while(!posNum);
			
		// Pass the cuboid's width back to the set method
		cuboid.setWidth(width);
		
		// Height
		
		// Use a do-while loop to validate that input is a positive number
		do {
		
			// Get the height
			height = (MessageBox.show("Please enter the height of the cuboid:", "Cuboid"));
			
			// Try-Catch block to validate input is a number
			try {
				
				// Check if height is a positive number
				if (height < MIN_DIMENSION) {
					
					height = (MessageBox.show("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
						+ "Height must be a positive number.", "Cuboid - Error"));
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				height = MessageBox.show("<html><b style='color:red'>Please enter the height"
						+ " of the cuboid:</b><br>"
					+ "Height must be a positive number.", "Cuboid - Error");
			}
			
		} while(!posNum);
			
		// Pass the cuboid's height back to the set method
		cuboid.setHeight(height);
		
		// Depth
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
		// Get the depth
		depth = (MessageBox.show("Please enter the depth of the cuboid:",
				"Cuboid"));
		
		// Try-Catch block to validate input is a number
		try {
			
			// Validate that the depth is a positive number
			if (depth < MIN_DIMENSION) {
				
				// Error message/try again
				depth = MessageBox.show("<html><b style='color:red'>Please enter the depth of the cuboid:</b><br>"
						+ "Depth must be a positive number.", "Cuboid - Error");
			}
			
			posNum = true;
			
		} catch (NumberFormatException e) {
			
			// Error message/try again
			depth = MessageBox.show("<html><b style='color:red'>Please enter the depth of the cuboid:</b><br>"
				+ "Depth must be a positive number.", "Cuboid - Error");
			
		}
		
	} while(!posNum);
		
		// Pass the cuboid's depth back to the set method
			cuboid.setDepth(depth);
		
		//
		//
		
		// Create a new Cylinder object
		Cylinder cylinder = new Cylinder(messageBox, radius, height);
		
		Shape cylinder1 = shapeFactory.make(ShapeType.Cylinder);
		cylinder1.setMessageBox(messageBox);
		
		// Radius
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
		// Get the radius
		radius = (MessageBox.show("Please enter the radius of the cylinder", "Cylinder"));
		
		// Try-Catch block to validate input is a number
		try {
			
			// Validate that the radius is a positive number
			if (radius < MIN_DIMENSION) {
				
				// Error message/try again
				radius = MessageBox.show("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
						+ "Radius must be a positive number.", "Cylinder - Error");
			}
			
			posNum = true;
			
		} catch (NumberFormatException e) {
			
			radius = MessageBox.show("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
				+ "Radius must be a positive number.", "Cylinder - Error");
		}
		
		
	} while(!posNum);
		
		// Set the cylinder's radius back to the set method
		cylinder.setRaidus(radius);
		
		// Height
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the height
			height = (MessageBox.show("Please enter the height of the cylinder: ", "Cylinder"));
			
			// Try-Catch block to validate input is a number
			try {
				
				// Validate that the width is a positive number
				if (height < MIN_DIMENSION) {
					
					// Error message/try again
					height = MessageBox.show("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
							+ "Height must be a positive number.", "Cylinder - Error");
					
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				// Error message/try again
				height = MessageBox.show("<html><b style='color:red'>Please enter the height of the cuboid:</b><br>"
					+ "Height must be a positive number.", "Cylinder - Error");
			}
			
		} while(!posNum);
			
		// Set the cylinder's height back to the set method
		cylinder.setHeight(height);
			
		//
		//
		
		// Create a new Sphere object
		Sphere sphere = new Sphere(messageBox, radius);
		
		Shape sphere1 = shapeFactory.make(ShapeType.Sphere);
		sphere1.setMessageBox(null);
		
		// Radius
		
		// Use a do-while loop to validate that input is a positive number
		do {
			
			// Get the radius
			radius = MessageBox.show("Please enter the radius of the sphere.", "Sphere");
			
			// Try-Catch block to validate input is a number
			try {
				
				// Validate that the radius is a positive number
				if (radius < MIN_DIMENSION) {
					
					// Error message/try again
					radius = MessageBox.show("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
							+ "Radius must be a positive number.", "Sphere - Error");
				}
				
				posNum = true;
				
			} catch (NumberFormatException e) {
				
				// Error message/try again
				radius = MessageBox.show("<html><b style='color:red'>Please enter the radius of the cuboid:</b><br>"
					+ "Radius must be a positive number.", "Sphere - Error");
			}
			
		} while(!posNum);
		
		// Set the sphere's radius back to the set method
		sphere.setRadius(radius);
		
		// Call the render method for the dialog boxes for each shape
		// 3 boxes total
		cuboid.render();
		cylinder.render();
		sphere.render();
		
	}

}
