package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */
public class ShapeFactory {
	
	// Variable
	private Dialog dialog; 
	
	// getDialog() method
	@SuppressWarnings("unused")
	private Dialog getDialog() {
		return dialog;
	}
	
	// setDialog() method
	@SuppressWarnings("unused")
	private void setDialog(Dialog dialog) {
		this.dialog = dialog;
	}
	
	// ShapeFactory(Dialog dialog) constructor
	public ShapeFactory(Dialog dialog) {
		
	}
	
	// make(ShapeType type) method that uses the ShapeType
	// enum to determine which shape to instantiate and return
	public Shape make(ShapeType type) {
		if(type == null){
	         return null;
	      }		
	      if(type.equals("Cuboid")){
	         return new Cuboid(dialog, 0, 0, 0);
	         
	      } else if(type.equals("Cylinder")) {
	         return new Cylinder(dialog, 0, 0);
	         
	      } else if(type.equals("Sphere")){
	         return new Sphere(dialog, 0);
	      }
	      
	      return null;
	   }
}
