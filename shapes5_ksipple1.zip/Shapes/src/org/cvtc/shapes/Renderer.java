package org.cvtc.shapes;

/**
 * @author ksipple1
 *
 */

public interface Renderer {

	void render();
	
}
